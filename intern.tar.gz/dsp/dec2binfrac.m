% Fall til a� breyta tugabrotum i binary-brot
% H�fundur: David Orn Sigthorsson
% Dagsetn.: vor 2002
%
% y = dec2binfrac(x,n);
% x     - tugabrots inntaks tala (tekur ekki vid neg. tolu)
% n     - fjoldi aukastafa (aftan kommu), sker af auka bita- ekki rounding, default 24
% y     - (strengur) tala sem samsvarar binary broti

function y = dec2binfrac(x,n)

y = dec2bin(x);     % Find integer value
x = x-bin2dec(y);   % Seperate the integer from the fraction, now we'll only consider the fraction
y = mat2str([y, '.']);

if(exist('n')==0) n = 24; end

tmp = 0;
for i=1:n
    tmp = x*2;
    y = mat2str([y num2str(fix(tmp))]);
    x = tmp - fix(tmp);    
end




