% Fall til a� breyta binary-broti i tugabrots tolu (decimal)
% H�fundur: David Orn Sigthorsson
% Dagsetn.: vor 2002
%
% x = binfrac2dec(y,n);
% x     - tugabrots tala
% n     - fjoldi aukastafa (aftan kommu), default allir
% y     - (strengur) tala sem samsvarar binary broti, positive

function x = binfrac2dec(y,n)

komma = find(y=='.');

yint = y(1:(komma-1));
yfrac = y((komma+1):length(y));

if(exist('n')==0); n = length(y)-(komma); end

yint = bin2dec(yint);
x = yint;
for i=1:n
    x = x + str2num(yfrac(i))*(2^(-i));
end

    