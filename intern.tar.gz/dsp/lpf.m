pkg load signal
## Compare the performance of a rolling average and sinc FIR filter

taps = 20;
coeffs = fir1(taps,0.5);
coeffs_avg = ones(1,taps)./taps;
f = [0 .5 .5 1];m = [1 1 0 0];
coeffs_custom = fir2(taps,f,m)

grid on

[h, w] = freqz(coeffs);
[h_avg, w_avg] = freqz(coeffs_avg);
[h_custom, w_custom] = freqz(coeffs_custom);
plot(w_avg/pi,abs(h_avg),';avg. response;',
     w/pi,abs(h),';sinc response;')
     ## w_custom/pi,abs(h_custom),';custom response;');
