#!/bin/octave
## Evan Widloski - 2016-07-14
## See what happens when filter coefficients are modified

duration = 1;
sample_freq = 50;

N = duration*sample_freq;

n = 0:N-1;

x = [1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

## show original signal DFT components
subplot(4,1,1)
plot(n,real(x),'r',n,imag(x),'g')
grid on
legend('Real','Imaginary','location','northeastoutside')
title(sprintf('Original Signal'))

x_f = ifft(x)

## modify the signal
## x_f_mod = i*imag([x_f(:,1:10) zeros(1,length(x_f)-10*2) x_f(:,end-9:end)]);
## x_f_mod = real([x_f(:,1:10) zeros(1,length(x_f)-10*2) x_f(:,end-9:end)]);
x_f_mod = real([x_f(:,1:10) zeros(1,length(x_f)-10*2) x_f(:,end-9:end)]) + i*imag([x_f(:,1:10) zeros(1,length(x_f)-10*2) x_f(:,end-9:end)]) ;
## x_f_mod = real(x_f);

## plot IFFT for comparison
subplot(4,1,2)
plot(n,real(x_f),'r',n,real(x_f_mod),'ro')
legend('original','modified','location','northeastoutside')
grid on
title('IFFT - Real')
subplot(4,1,3)
plot(n,imag(x_f),'g',n,imag(x_f_mod),'go')
legend('original','modified','location','northeastoutside')
grid on
title('IFFT - Imaginary')



subplot(4,1,4)
plot(n,real(fft(x_f_mod)),'r',n,imag(fft(x_f_mod)),'g')
grid on
legend('Real','Imaginary','location','northeastoutside')
title(sprintf('FFT after modification'))

print -dpng '/tmp/test.png'
